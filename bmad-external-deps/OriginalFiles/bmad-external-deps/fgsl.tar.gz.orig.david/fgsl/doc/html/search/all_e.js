var searchData=
[
  ['r_2538',['r',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a3353b0664ef271acdce6aa4b92ace197',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['rmse_2539',['rmse',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a9ab711f917ad9f632ab668ddfa73adfb',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['rng_2efinc_2540',['rng.finc',['../rng_8finc.html',1,'']]],
  ['roots_2efinc_2541',['roots.finc',['../roots_8finc.html',1,'']]],
  ['rsq_2542',['rsq',['../structfgsl_1_1fgsl__multifit__robust__stats.html#ad2d659d16fd8061bd781d1586a5f81d3',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['rstat_2efinc_2543',['rstat.finc',['../rstat_8finc.html',1,'']]]
];
