var searchData=
[
  ['params_5119',['params',['../structfgsl_1_1fgsl__movstat__function.html#a35da58e8d84fbce097a1200c34da3766',1,'fgsl::fgsl_movstat_function']]]
];
