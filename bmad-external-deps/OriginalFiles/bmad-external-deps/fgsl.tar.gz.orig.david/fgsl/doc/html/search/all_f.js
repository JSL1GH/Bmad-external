var searchData=
[
  ['sigma_2544',['sigma',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a5da53015a9d12f1c5efca715e3db852b',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['sigma_5fmad_2545',['sigma_mad',['../structfgsl_1_1fgsl__multifit__robust__stats.html#aa9d516d07e5792e733b0074d4b402999',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['sigma_5fols_2546',['sigma_ols',['../structfgsl_1_1fgsl__multifit__robust__stats.html#adf176fab65c7036d151f74de617d219a',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['sigma_5frob_2547',['sigma_rob',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a5584eeb03f4001749227079089275075',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['siman_2efinc_2548',['siman.finc',['../siman_8finc.html',1,'']]],
  ['sort_2efinc_2549',['sort.finc',['../sort_8finc.html',1,'']]],
  ['specfunc_2efinc_2550',['specfunc.finc',['../specfunc_8finc.html',1,'']]],
  ['splinalg_2efinc_2551',['splinalg.finc',['../splinalg_8finc.html',1,'']]],
  ['spmatrix_2efinc_2552',['spmatrix.finc',['../spmatrix_8finc.html',1,'']]],
  ['sse_2553',['sse',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a137f634721561413a40c1269d954a504',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['statistics_2efinc_2554',['statistics.finc',['../statistics_8finc.html',1,'']]],
  ['sum_5flevin_2efinc_2555',['sum_levin.finc',['../sum__levin_8finc.html',1,'']]]
];
