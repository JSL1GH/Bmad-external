var searchData=
[
  ['permutation_2efinc_2760',['permutation.finc',['../permutation_8finc.html',1,'']]],
  ['poly_2efinc_2761',['poly.finc',['../poly_8finc.html',1,'']]]
];
