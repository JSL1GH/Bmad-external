var searchData=
[
  ['r_5120',['r',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a3353b0664ef271acdce6aa4b92ace197',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['rmse_5121',['rmse',['../structfgsl_1_1fgsl__multifit__robust__stats.html#a9ab711f917ad9f632ab668ddfa73adfb',1,'fgsl::fgsl_multifit_robust_stats']]],
  ['rsq_5122',['rsq',['../structfgsl_1_1fgsl__multifit__robust__stats.html#ad2d659d16fd8061bd781d1586a5f81d3',1,'fgsl::fgsl_multifit_robust_stats']]]
];
