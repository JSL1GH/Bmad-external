var searchData=
[
  ['linalg_2efinc_2503',['linalg.finc',['../linalg_8finc.html',1,'']]]
];
