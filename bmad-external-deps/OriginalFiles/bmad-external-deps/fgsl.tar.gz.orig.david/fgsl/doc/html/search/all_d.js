var searchData=
[
  ['params_2535',['params',['../structfgsl_1_1fgsl__movstat__function.html#a35da58e8d84fbce097a1200c34da3766',1,'fgsl::fgsl_movstat_function']]],
  ['permutation_2efinc_2536',['permutation.finc',['../permutation_8finc.html',1,'']]],
  ['poly_2efinc_2537',['poly.finc',['../poly_8finc.html',1,'']]]
];
