var searchData=
[
  ['siman_2efinc_2765',['siman.finc',['../siman_8finc.html',1,'']]],
  ['sort_2efinc_2766',['sort.finc',['../sort_8finc.html',1,'']]],
  ['specfunc_2efinc_2767',['specfunc.finc',['../specfunc_8finc.html',1,'']]],
  ['splinalg_2efinc_2768',['splinalg.finc',['../splinalg_8finc.html',1,'']]],
  ['spmatrix_2efinc_2769',['spmatrix.finc',['../spmatrix_8finc.html',1,'']]],
  ['statistics_2efinc_2770',['statistics.finc',['../statistics_8finc.html',1,'']]],
  ['sum_5flevin_2efinc_2771',['sum_levin.finc',['../sum__levin_8finc.html',1,'']]]
];
